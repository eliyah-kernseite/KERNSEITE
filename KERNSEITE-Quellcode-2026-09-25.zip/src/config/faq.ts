export interface FaqItem {
  readonly question: string;
  readonly answer: string;
  /** Auf der Startseite anzeigen (Auszug). */
  readonly onHome?: boolean;
  /** Zu welchen Leistungen passt die Frage (service keys)? */
  readonly services?: readonly string[];
}

/**
 * FAQ – ehrliche, konkrete Antworten ohne Rechts- oder Erfolgsgarantien.
 * Wird für die FAQ-Seite und (Auszug) für die Startseite genutzt.
 * Die FAQPage-strukturierten Daten werden nur aus tatsächlich sichtbaren Fragen erzeugt.
 */
export const faqs: readonly FaqItem[] = [
  {
    question: 'Was kostet eine individuelle Website?',
    services: ['websites'],
    answer:
      'Der Orientierungsrahmen für Unternehmenswebsites liegt meist bei 1.500–5.500 € netto, zuzüglich gesetzlicher Umsatzsteuer, soweit diese anfällt. Umfang, Seitenanzahl und Funktionen bestimmen das Angebot. Domain, Hosting, laufende Betreuung sowie zusätzliche Fotografie, Video und Rechtsberatung werden separat vereinbart.',
    onHome: true,
  },
  {
    question: 'Wie lange dauert ein Website-Projekt?',
    services: ['websites'],
    answer:
      'Ein typisches Projekt dauert je nach Umfang und Zuarbeit einige Wochen. Entscheidend ist, wie schnell Inhalte, Bilder und Freigaben vorliegen. Den realistischen Zeitrahmen legen wir gemeinsam zu Beginn fest.',
    onHome: true,
  },
  {
    question: 'Funktioniert die Zusammenarbeit auch bundesweit?',
    services: ['websites'],
    answer:
      'Ja. Konzept, Entwürfe und Rückmeldungen stimmen wir per Telefon, Videogespräch und gemeinsamer Website-Vorschau ab. Im Raum Würzburg und Schweinfurt sind nach Absprache persönliche Termine möglich. Dein Ansprechpartner bleibt Eliyah Korb.',
    onHome: true,
  },
  {
    question: 'Kann meine bestehende Website übernommen werden?',
    services: ['websites'],
    answer:
      'Inhalte wie Texte und Bilder lassen sich oft übernehmen und aufbereiten. Ob die bestehende technische Basis sinnvoll weitergeführt wird, prüfen wir im Einzelfall – manchmal ist ein sauberer Neuaufbau der bessere Weg.',
  },
  {
    question: 'Wer erstellt Texte, Bilder und Videos?',
    services: ['websites', 'video', 'social'],
    answer:
      'Wir unterstützen bei Struktur und Formulierung der Texte und planen Bildmotive mit. Fachliche Inhalte kommen von dir. Für Video arbeiten wir mit einem spezialisierten Partner. Was jeweils von wem kommt, halten wir zu Projektbeginn klar fest.',
    onHome: true,
  },
  {
    question: 'Kann ich Inhalte später ändern lassen?',
    services: ['websites'],
    answer:
      'Ja. Änderungen und Weiterentwicklungen vereinbaren wir als gesonderte Leistung. Je nach Wunsch übernehmen wir Anpassungen oder richten Wege ein, über die du selbst Inhalte pflegen kannst.',
  },
  {
    question: 'Übernehmt ihr Hosting und Wartung?',
    services: ['websites'],
    answer:
      'Ja. Auf Wunsch übernehmen wir Hosting, Updates, Sicherung und laufende Betreuung, damit die Website dauerhaft schnell und sicher bleibt.',
    onHome: true,
  },
  {
    question: 'Ist die Website für Smartphones optimiert?',
    services: ['websites', 'seo-geo'],
    answer:
      'Ja. Das mobile Layout wird eigenständig gestaltet, nicht nur verkleinert. Navigation, Lesbarkeit und Kontaktwege werden auch auf kleinen Bildschirmen geprüft.',
  },
  {
    question: 'Was bedeutet SEO und GEO?',
    services: ['seo-geo', 'google'],
    answer:
      'SEO steht für Suchmaschinenoptimierung: technisch saubere, gut auffindbare Seiten. GEO und GAIO beschreiben die Optimierung von Inhalten für KI-Antwortsysteme. Eindeutige Fakten und hilfreiche Antworten verbessern die Voraussetzungen; ob ein System die Inhalte verwendet, entscheidet der jeweilige Anbieter. Beides gehört zur Grundlage jeder KERNSEITE.',
  },
  {
    question: 'Kann ein Google-Unternehmensprofil optimiert werden?',
    services: ['google', 'seo-geo'],
    answer:
      'Ja. Wir richten das Profil sauber ein oder optimieren es: Kategorien, Leistungen, Bilder und Bewertungsprozess. Ranking-Garantien gibt es dabei bewusst nicht – lokale Sichtbarkeit entsteht durch konsistente, gepflegte Daten.',
  },
  {
    question: 'Wie funktionieren Chatbot und Voice Agent?',
    services: ['ki'],
    answer:
      'Ein Chatbot beantwortet auf der Website häufige Fragen und bereitet Anfragen vor. Ein Voice Agent ist ein sprachgesteuerter Assistent, der z. B. Routineanfragen entgegennimmt. Beide entlasten bei wiederkehrenden Abläufen und übergeben bei Bedarf an einen Menschen.',
  },
  {
    question: 'Mit wem schließe ich den Vertrag?',
    services: ['video', 'social', 'ki'],
    answer:
      'Dein Vertragspartner ist KERNSEITE – Eliyah Korb. Eliyah ist dein zentraler Ansprechpartner und steuert das Projekt, auch wenn einzelne Leistungen über Partner umgesetzt werden.',
  },
  {
    question: 'Arbeitet KERNSEITE mit Subunternehmern?',
    services: ['video', 'social', 'ki'],
    answer:
      'Für Film, Social Media und KI arbeiten wir projektbezogen mit spezialisierten selbstständigen Partnern zusammen. Die Kommunikation bleibt zentral bei KERNSEITE, während jede Aufgabe von der passenden Fachperson umgesetzt wird.',
  },
  {
    question: 'Sind Datenschutz und Barrierefreiheit enthalten?',
    services: ['websites', 'seo-geo'],
    answer:
      'Datenschutzfreundliche Planung und Barrierearmut nach modernen Standards gehören zur Grundumsetzung. Die technische Umsetzung berücksichtigt Datenschutz und Zugänglichkeit. Rechtstexte und die für dein Unternehmen geltenden Pflichten lässt du fachlich prüfen. Eine automatische „Rechtssicherheit“ sagen wir bewusst nicht zu.',
  },
];

export const homeFaqs = faqs.filter((f) => f.onHome).slice(0, 4);
